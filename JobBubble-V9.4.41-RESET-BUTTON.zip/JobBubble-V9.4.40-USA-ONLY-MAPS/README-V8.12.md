# JobBubble V8.12

- Job detail popup changed to a darker translucent violet glass treatment.
- Violet outline retained for definition over the navy map.
- Existing centered popup layout and pinned Save / Follow / Apply action row retained.
- V8.11 modern top icons and deep navy interactive map retained.
