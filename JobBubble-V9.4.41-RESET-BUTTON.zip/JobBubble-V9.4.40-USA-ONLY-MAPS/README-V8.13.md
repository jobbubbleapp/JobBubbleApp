# JobBubble V8.13

Adds interactive distance and minimum-pay controls. Tap **25 mi** or **$15+** to open a focused editor with both a slider and a numeric entry field. The main filter sheet also supports sliders plus exact typed values. Distance supports 1–100 miles and minimum hourly pay supports $0–$100+/hr.
