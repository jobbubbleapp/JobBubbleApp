# JobBubble V8.16

- Light mode is now the default on first launch of this build.
- Light mode uses a coordinated light-gray UI across the header, filter chips, navigation, dialogs, lists, search, settings, and job cards.
- Dark mode remains available in Settings and keeps the darker violet treatment.
- Search now opens a dedicated modern search panel with live filtering by job title, company, category, and source.
- List and Saved use modern job cards instead of the plain Android list dialog.
- Preserves Extended distance, manual distance/pay entry, modern category/source popups, and the interactive vector map.
