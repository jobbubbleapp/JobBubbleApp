# JobBubble V9.4.36

- Android versionCode 75 / versionName 9.4.36.
- U.S.-only map presentation: Canada and Mexico are covered by opaque gray country curtains so roads, cities, POIs, terrain labels, and other map details underneath are not visible.
- Adds clean JobBubble-owned country labels (Canada / Mexico) above the curtains.
- Foreign-country labels hide at close street zoom while the gray curtain remains.
- Replaces the previous visually broken low-zoom foreign-country masking approach with stable map polygons.
- Backend remains V9.4.34.
