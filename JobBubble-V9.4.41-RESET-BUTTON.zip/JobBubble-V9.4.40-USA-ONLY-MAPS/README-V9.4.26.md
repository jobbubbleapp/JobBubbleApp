# JobBubble V9.4.26

Compile fix for the map hold gesture introduced in V9.4.25. The hold-action Runnable is now initialized inside MapHoldOverlay's constructor after `mapTarget` is assigned, fixing Java definite-assignment error: `variable mapTarget might not have been initialized`.

- versionCode: 68
- versionName: 9.4.26
- Keeps V9.4.25 pile-spread and hold-location behavior.
