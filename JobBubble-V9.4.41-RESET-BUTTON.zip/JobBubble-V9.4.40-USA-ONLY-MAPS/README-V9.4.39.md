# JobBubble V9.4.39 — U.S. Region Maps

- Default map is the contiguous United States (Lower 48).
- Settings > Map region adds three choices: United States, Alaska, Hawaii.
- Alaska and Hawaii each use their own dedicated camera bounds and overview.
- Foreign-country labels are hidden at the Google map-style level.
- Canada/Mexico/nearby foreign areas remain covered by the label-proof tile curtain where needed.
- Foreign-country labels are no longer drawn by JobBubble.
- Map long-press location selection is rejected outside the currently selected U.S. region.
- Map-region preference is saved locally and synced with the existing Firestore user profile.
- V9.4.38 performance improvements are retained.
