# JobBubble V8

V8 is based directly on the working V7.3 map build.

Kept from V7.3:
- OpenFreeMap/MapLibre + Leaflet vector map
- draggable/pinch-zoom map
- dark map with dark-blue water
- compact job bubbles and provider badges
- welcome/create account/login/Continue as Guest flow
- filters, saved jobs, follow jobs, profile and settings

V8 changes:
- modern compact/expandable job detail bottom sheet
- short job descriptions
- degree, license, schedule and experience requirements
- recognizable demo employers (not live listings)
- company career-site links for demo View on Website actions
- welcome screen is shown once after upgrading to V8

Demo employer/job data is illustrative until a live jobs API/backend is connected.
