# JobBubble V8.20

Fixes Android Java compilation by using fully-qualified `android.content.res.ColorStateList` for the light-mode popup action button text colors.
