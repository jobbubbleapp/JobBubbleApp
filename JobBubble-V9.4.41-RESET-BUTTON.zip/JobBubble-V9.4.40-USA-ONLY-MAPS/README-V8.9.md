# JobBubble V8.9

- Save / Follow / Apply are pinned inside the popup and cannot be pushed below the screen.
- Popup is raised above app navigation and Android system navigation.
- Top controls are tighter and more modern.
- All jobs / All sources use compact fixed widths instead of stretching across the screen.
- Search and filter use vector icons instead of font glyphs.
