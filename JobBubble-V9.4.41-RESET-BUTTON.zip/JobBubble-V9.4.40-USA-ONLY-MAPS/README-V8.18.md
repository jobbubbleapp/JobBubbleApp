# JobBubble V8.18

Light-mode selection popup cleanup.

- Job Source and Job Category use one consistent light-gray modern popup.
- Removed unwanted bullet placeholders for source rows.
- Radio controls no longer receive boxed backgrounds.
- Compact row heights keep all options accessible; long lists scroll when needed.
- All-sources/all-jobs helper text is no longer clipped.
- Cancel uses a light-gray neutral button in light mode; Apply keeps violet accent.
- Dark mode keeps the dark violet styling.
