# JobBubble V8.19

Fixes light-mode action buttons in Job Source and Job Category popups. Cancel is now a true light-gray outlined button with dark text; Apply keeps a darker violet gradient with forced white text so Android theme tint cannot make it unreadable.
