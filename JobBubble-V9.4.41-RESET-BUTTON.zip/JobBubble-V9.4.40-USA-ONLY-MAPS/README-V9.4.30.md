# JobBubble V9.4.30

Backend location-resolution upgrade.

- Adds a long-lived in-process workplace cache so repeated jobs for the same employer/location reuse a resolved workplace instead of spending another lookup.
- Exact provider street addresses remain exact.
- Street addresses found in job descriptions are geocoded and treated as high-confidence likely locations.
- Company/location workplace matches are cached and reused.
- If no confident workplace match can be found, JobBubble does **not** drop the job or invent a precise address. It preserves the provider coordinate when available as the best posting-specific area estimate.
- If provider coordinates are missing, it geocodes the posting's city/ZIP/location text and uses that area centroid as the last-resort estimate.
- Adds `location_confidence` and clearer `location_match_provider` metadata.
- Existing V9.4.29 Android cluster behavior is preserved.

This is the first step toward a larger self-reusing workplace index that minimizes external searches.
