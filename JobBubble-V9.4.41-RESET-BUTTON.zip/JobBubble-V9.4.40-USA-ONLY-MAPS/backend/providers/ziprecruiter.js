module.exports = { name: 'ZipRecruiter', async search(query) {
  // Implement only with the ZipRecruiter partner product/feed that grants job-search/listing access.
  if (!process.env.ZIPRECRUITER_ENABLED) return [];
  throw new Error('ZipRecruiter provider credentials/approved integration not configured');
}};
