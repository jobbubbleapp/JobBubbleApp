module.exports = { name: 'Glassdoor', async search(query) {
  // Implement with Glassdoor partner/API access. Keep all secrets server-side and preserve required attribution.
  if (!process.env.GLASSDOOR_ENABLED) return [];
  throw new Error('Glassdoor provider credentials/approved integration not configured');
}};
