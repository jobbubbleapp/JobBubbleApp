module.exports = { name: 'Indeed', async search(query) {
  // Implement only after Indeed approves the integration and supplies the applicable partner credentials/feed.
  // Map the approved response to JobBubble's normalized fields documented in ../README.md.
  if (!process.env.INDEED_ENABLED) return [];
  throw new Error('Indeed provider credentials/approved integration not configured');
}};
