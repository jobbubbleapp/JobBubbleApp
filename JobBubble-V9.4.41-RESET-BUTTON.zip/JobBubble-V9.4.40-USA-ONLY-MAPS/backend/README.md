# JobBubble backend gateway

This folder is the server-side boundary between the Android app and job providers. Do not put Indeed, Glassdoor, ZipRecruiter, or other provider secrets in the APK.

## Run locally
`node server.js`

Endpoints: `GET /health`, `GET /jobs?lat=47.98&lon=-122.20&radius=25&minPay=15&category=All%20jobs&source=All%20sources`

The Android app expects `{ "jobs": [...] }`. Each normalized job may contain:
`id, source, title, company, latitude, longitude, salary_min, salary_max, category, apply_url, logo_url, description, posted_at`.

## Connect Android
Deploy this folder to an HTTPS host, then edit `app/src/main/res/values/job_api.xml` and replace `https://YOUR_BACKEND_URL/jobs` with the public `/jobs` URL.

The three provider modules are deliberately credential-free adapters. Add provider calls only after you have the corresponding approved API/feed/partner access and follow each provider's terms and attribution rules.
