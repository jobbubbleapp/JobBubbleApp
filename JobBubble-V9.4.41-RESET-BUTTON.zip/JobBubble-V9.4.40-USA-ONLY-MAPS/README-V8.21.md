# JobBubble V8.21

Settings cleanup release.

- Settings sheet is scrollable and expands fully so Account, Sign out, and Done remain reachable above Android system navigation.
- Version label corrected to v8.21.
- Extended distance uses a styled violet switch instead of a default checkbox.
- Map appearance options use consistent custom light-gray/dark-violet selector cards.
- Settings spacing and explanatory copy are tightened.
- Light mode uses light-gray settings surfaces and readable dark text throughout.
