# JobBubble V9.4.38 Performance

Performance-focused release based on V9.4.37.

Android changes:
- Replaced all-pairs O(n^2) screen clustering with a screen-space bucket index that preserves precise-vs-approximate stack separation.
- Added an LRU cache for Canada/Mexico curtain tiles and skips tile rendering outside those country bounds.
- Coalesces repeated map rebuilds caused by company-logo downloads.
- Debounces pay-slider map refreshes while dragging.
- Marker bitmap cache now distinguishes placeholder-vs-downloaded logo state.

Backend V9.4.35 changes:
- Deduplicates concurrent posting-page fetches for the same apply URL.
- Deduplicates concurrent Firestore workplace-cache reads for the same workplace key.
- Periodically prunes/caps job, geo, posting-page, and workplace in-memory caches to prevent long-running Render memory growth.
- Preserves V9.4.34 exact-address lookup, high-confidence-only Firestore persistence, and best-estimate fallback.
