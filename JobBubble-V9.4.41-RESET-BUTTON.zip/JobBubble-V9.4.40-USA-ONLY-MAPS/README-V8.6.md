# JobBubble V8.6

UI refinement based on the approved target mockup:
- Job details card uses wrap-content sizing rather than filling nearly the entire screen.
- Card is positioned above the app bottom navigation with dedicated clearance.
- Save, Follow, and blue Apply buttons stay fully visible.
- Existing dark map, compact employer/pay pins, filters, and navigation are preserved.
