# JobBubble V9.4.27

- Fixes hold/slide map location selection jumping to Boston.
- The selected coordinate is now authoritative for map centering and distance calculations.
- Reverse-geocodes the selected point to a city/state label for Adzuna/USAJOBS provider searches.
- Always sends the exact selected lat/lon to the V9.4.23 backend.
- Same/near-identical job coordinates now progressively expand at close zoom instead of remaining a permanent pile.
- Progressive reveal: up to 4 jobs around zoom 18.15, 7 around 19.25, and 10 around 20.15; remaining jobs stay in a center pile.
- Expansion spacing accounts for the full job card footprint to reduce overlap.
- VersionCode 69 / VersionName 9.4.27.
