# JobBubble V8.2 Target UI

This build keeps the working V7.3 map foundation and updates the main map/details UI to the approved dark JobBubble target design.

Changes:
- Dark map is the default, with dark-blue water.
- Compact branded employer markers replace text-heavy map bubbles.
- Header/filter layout updated to match the approved mockup.
- Bottom navigation is Map / List / Saved / Profile.
- Job sheet keeps description, job type, location, schedule, degree, license and experience details.
- Skills/tag pills removed.
- Purple "View on Website" action removed.
- Blue Apply button opens the demo employer careers URL.
- Demo roles use realistic employer job titles; they are not claimed to be current live openings.

Compatibility remains Java 8 / legacy Gradle setup used by the prior working project.
