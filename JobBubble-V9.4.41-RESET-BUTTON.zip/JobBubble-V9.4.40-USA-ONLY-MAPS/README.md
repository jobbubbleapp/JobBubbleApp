# JobBubble V4

Android Studio project for the JobBubble map-based job finder.

## Current toolchain

Configured for Android Studio Quail 4 / Android Gradle Plugin 9.4.0 and Gradle 9.6.0. AGP 9.4 requires JDK 17 and Gradle 9.6.0.

## Open and run

1. Install Android Studio Quail 4 (2026.1.4) or another compatible current stable Android Studio.
2. Open this folder (`JobBubble-V3`) in Android Studio.
3. Let Gradle sync and install any requested SDK components.
4. Create `local.properties` in the project root and add:
   MAPS_API_KEY=YOUR_GOOGLE_MAPS_ANDROID_KEY
5. Enable Maps SDK for Android for that key in Google Cloud.
6. Connect your Android phone with USB debugging enabled, or use an emulator.
7. Press Run.

## Demo mode

The app works without a job backend. It displays demo job bubbles near the detected location.

## Live jobs

Set `JOB_API_URL` in `MainActivity.java` to your deployed backend endpoint. The endpoint should return:

{
  "jobs": [
    {
      "title": "Warehouse Associate",
      "company": "Example Company",
      "latitude": 47.98,
      "longitude": -122.20,
      "salary_min": 21.50,
      "category": "Warehouse",
      "apply_url": "https://example.com/job"
    }
  ]
}

The app then filters by distance, minimum pay, and category.

## Build a debug APK

In Android Studio:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

The debug APK will normally appear under:
app/build/outputs/apk/debug/app-debug.apk


## V4
Adds Job Source filtering and compact rounded map bubbles with green pay and a circular source badge.

# V6 changes
- New dark, low-glow welcome/home screen matching the approved design.
- Create Account and Log In demo screens.
- Continue as Guest option.
- Existing location/map, pay/distance/category/source filters retained.
- Source badges and compact job bubbles retained.
- Account buttons are UI/demo only until a real authentication provider is configured.
- Dense-map clustering is a planned production integration; this source build retains the existing marker renderer.
