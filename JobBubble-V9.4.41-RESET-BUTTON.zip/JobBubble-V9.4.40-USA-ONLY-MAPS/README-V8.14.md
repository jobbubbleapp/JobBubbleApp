# JobBubble V8.14 — Extended Distance

Adds an **Extended distance** option under Settings.

- Standard mode: distance filter supports 1–100 miles.
- Extended distance enabled: distance filter supports 1–10,000 miles.
- Users can use the slider or type an exact distance, including values above 5,000 miles.
- Turning Extended distance off automatically clamps an existing distance above 100 miles back to 100 miles.
- The setting is saved on-device.

Live results still depend on the connected jobs backend/API honoring the requested radius.
