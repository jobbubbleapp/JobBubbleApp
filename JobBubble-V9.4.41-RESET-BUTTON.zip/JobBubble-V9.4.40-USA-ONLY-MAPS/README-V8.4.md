# JobBubble V8.4

- Pay amounts on map job pins are green.
- Job-detail sheet opens fully expanded so description, requirements, and actions are not cut off.
- Added extra bottom padding for gesture/navigation-bar clearance.
- Keeps V8.3 compact employer-logo pins, job titles, blue Apply button, and existing map behavior.
