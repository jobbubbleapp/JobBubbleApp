# JobBubble V8.15

- Replaced the plain Android category/source dialogs with centered dark-violet glass modals.
- Added purple selection states, compact icon rows, a modern close button, and Cancel / Apply actions.
- Preserves V8.14 extended distance and manual distance/pay entry.
