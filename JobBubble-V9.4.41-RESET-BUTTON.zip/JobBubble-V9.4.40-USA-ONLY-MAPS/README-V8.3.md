# JobBubble V8.3

Based on the V8.2 target build.

Changes:
- Smaller branded employer icons on the map.
- Pay shown directly beside each employer icon.
- Compact job-position label under the pay.
- Keeps the V8.2 detailed job sheet with blue Apply button.
- No skills chips and no View on Website button.
- Preserves the working draggable/zoomable map and onboarding flow.
