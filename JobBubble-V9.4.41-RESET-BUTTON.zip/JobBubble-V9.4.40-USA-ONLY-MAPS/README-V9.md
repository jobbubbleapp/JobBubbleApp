# JobBubble V9.0

Version 9 introduces a richer profile and job-requirement matching system.

- New JobBubble app icon: simple map + purple job pin/briefcase.
- Profile supports name, age, degrees, certifications/licenses, and a profile picture.
- Profile picture can be selected from the gallery or captured with the device camera.
- Required degree and certification/license items turn green when the user's profile matches them.
- Missing required degree/certification items show in red until the matching profile item is added.
- Modern Android build target: compile/target SDK 35, AGP 8.7.3, Gradle 8.9, Java 17.
- Version name 9.0, version code 30.
