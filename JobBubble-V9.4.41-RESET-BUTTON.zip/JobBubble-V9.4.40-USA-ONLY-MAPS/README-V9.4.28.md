# JobBubble V9.4.28

Compile-fix release for V9.4.27.

- Fixes the Java compile error in progressive same-coordinate pile expansion where a float radiusDp was passed to dp(int).
- Keeps the pinned-location fix and progressive pile expansion behavior from V9.4.27.
- versionCode 70 / versionName 9.4.28.
