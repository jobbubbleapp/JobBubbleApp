# JobBubble V8.7
- Reverted to the approved compact $15+ filter (no large salary slider).
- Header/search/filter controls are smaller and cleaner.
- Job action row is raised and the bottom sheet reserves more bottom-safe space so Save, Follow, and Apply remain visible.
- Existing map, demo jobs, green pay labels, and job details are preserved.
