# JobBubble V9.4.29

- Earlier pile separation at street/neighborhood zoom levels.
- Newly separated bubbles animate outward from their previous pile position.
- Clusters larger than 5 open a scrollable right-side job list when tapped at close zoom.
- Same-coordinate piles of 5 or fewer progressively fan out earlier.
- Keeps V9.4.28 pinned-location and compile fixes.
