# JobBubble V8.17

Light-mode consistency update. All profile, settings, filter, search, list, saved, category/source, numeric-filter, and other popup controls now use light-gray surfaces with readable dark text, muted gray borders, violet accents, pale-red destructive actions, and consistent light-mode checkbox/radio styling. Dark mode remains unchanged.
