# JobBubble V9.4.40

- Strict U.S.-region map masking: everything outside the selected USA/Alaska/Hawaii region is hidden behind a solid overlay.
- Added persistent on-map region badge: USA MAP, ALASKA MAP, or HAWAII MAP.
- Hawaii opens at a closer overview zoom.
- Likely/high-confidence workplace pins no longer display the misleading "approx. location" label or approximate halo.
- Retains V9.4.38 performance optimizations and V9.4.39 region selector.
