# JobBubble V9.4.23

Fast-search Android update for the V9.4.23 backend.

- Existing jobs stay on the map while refreshing.
- First load can still show the full-screen loader when no jobs have been loaded yet.
- Source selection now reloads only the selected backend provider (Adzuna, USAJOBS, or all).
- Category and minimum-pay filtering remain local and instant.
- Distance changes still trigger a fresh provider search.
- Supports quick first results followed by `refined=1` location refinement without a duplicate provider search.
- Failed refreshes keep the last known live results instead of clearing the map.
- Keeps V9.4.22 pile clustering and true-coordinate behavior.
