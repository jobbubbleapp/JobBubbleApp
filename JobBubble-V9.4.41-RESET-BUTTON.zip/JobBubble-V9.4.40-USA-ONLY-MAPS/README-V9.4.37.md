# JobBubble V9.4.37

- Replaces the non-U.S. polygon curtains with a tile overlay that renders above Google base-map labels.
- Canada and Mexico are now opaque gray regions with only JobBubble-owned country names visible; roads, cities, province/state abbreviations, POIs, and Google country labels are covered.
- Constrains country-level camera framing around U.S. territory so the map no longer zooms out into South America or unrelated world regions.
- Keeps Alaska and Hawaii inside the supported camera bounds.
- Backend remains V9.4.34.
