# JobBubble V9.4.24

- Footprint-aware job piles: bubbles only split when their real screen positions have room for the full cards.
- Same/nearby coordinates remain piled even at maximum zoom; no radial fake-position fan-out.
- Removed per-frame camera focus work; clusters/focus update only when camera settles.
- LRU cache for rendered job marker bitmaps.
- Long-press map gesture: hold until ring appears, slide upward onto “Set as location”, release to save and search there.
- Keeps V9.4.23 fast-search backend behavior.
