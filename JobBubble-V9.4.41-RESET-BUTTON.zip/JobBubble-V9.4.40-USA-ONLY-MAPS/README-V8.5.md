# JobBubble V8.5

- Job detail sheet is constrained to the usable phone height.
- Job details scroll when necessary so the Apply/Follow/Save row is never permanently clipped.
- Added bottom safe-area clearance above Android navigation controls.
- Keeps green pay labels on compact map job pins and the V8.4 design.
