# JobBubble v7.3

Changes from v7.2:
- Job map bubbles now use compact company-style logo tiles (initials for demo/fallback jobs) with a small source-provider badge.
- Followed jobs keep the subtle light-green ring.
- Dark map water/ocean/river layers are recolored to a deeper dark blue when the vector style exposes those layers.
- Bottom navigation rebuilt as four equal-width centered tabs: Map, Saved, Profile, Settings.
- Job detail popup is now a compact floating bottom card with reduced padding/height and three inline actions: Save, Follow, View.
- Version bumped to 7.3 / versionCode 15.

Build note: this environment does not have the system Gradle executable required by the bundled wrapper shim, so a full Android Gradle build could not be run here. Java was syntax-checked with javac; only expected missing Android/AndroidX dependency errors were reported.
