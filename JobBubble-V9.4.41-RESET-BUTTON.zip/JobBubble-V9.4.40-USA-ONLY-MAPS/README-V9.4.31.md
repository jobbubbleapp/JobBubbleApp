# JobBubble V9.4.31 — Firestore persistent workplace cache

This build keeps all V9.4.30 Android behavior and upgrades the included Node backend.

Backend changes:
- Reads Firebase service account from `/etc/secrets/firebase-service-account.json` by default.
- Uses the Firestore REST API with short-lived OAuth tokens; no npm dependency is required.
- Resolved workplace matches are cached in memory and persisted in `workplace_cache` in Firestore.
- A Render restart no longer erases confirmed workplace matches.
- If Firestore is unavailable, JobBubble silently falls back to the in-memory cache and the normal best-estimate pipeline.
- Best-estimate fallback is preserved: provider coordinates first, then city/ZIP/location centroid if necessary.
- `/health` reports `firestore_workplace_cache: enabled` when the service-account secret was loaded.

Render secret file expected:
`/etc/secrets/firebase-service-account.json`

No API key or secret is bundled in this ZIP.
