# JobBubble V9.4.35

Android UI/filter update on top of the V9.4.34 backend.

- Exact/likely location filter in Filter jobs.
- Area-only jobs never share map piles with exact/high-confidence likely workplace jobs.
- Approximate stacks are labeled separately.
- “No degree stated” and “No certification stated” stay neutral instead of red.
- Precision-only preference is saved locally and synced with the existing Firestore user profile.
- Includes the V9.4.34 backend source for posting-page address lookup.
