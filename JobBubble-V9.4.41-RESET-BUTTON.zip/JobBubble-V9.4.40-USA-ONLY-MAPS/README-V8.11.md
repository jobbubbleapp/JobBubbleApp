# JobBubble V8.11

- New JobBubble map-pin logo icon
- Redesigned search, filters, location, pay, category, and source icons
- More subtle compact chip styling
- Deep navy OpenFreeMap vector treatment with dark-blue water, subdued roads/buildings, and brighter place labels
- Existing job popup, demo jobs, map interactions, follow/save/apply behavior preserved
